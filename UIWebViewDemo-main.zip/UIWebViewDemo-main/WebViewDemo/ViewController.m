//
//  ViewController.m
//  WebViewDemo
//
//  Created by Object on 2021/3/3.
//  Copyright © 2021 lsp. All rights reserved.
//

#import "ViewController.h"
#import <WebKit/WebKit.h>
#import "GRHWKURLSchemeHandler.h"
#import "CustomURLProtocol.h"
@interface ViewController ()

@property (nonatomic, strong) WKWebView *wkWebView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    
    NSString *jScript = @"window.webkit.messageHandlers.event.postMessage({\"\":\"\"});";
    WKUserScript *js = [[WKUserScript alloc] initWithSource:jScript injectionTime:WKUserScriptInjectionTimeAtDocumentEnd forMainFrameOnly:YES];
    
    WKWebViewConfiguration *configuration = [[WKWebViewConfiguration alloc] init];
    configuration.allowsInlineMediaPlayback = YES;
    configuration.mediaTypesRequiringUserActionForPlayback = NO;
    [configuration.userContentController addUserScript:js];
    [configuration setURLSchemeHandler:[[GRHWKURLSchemeHandler alloc] init] forURLScheme:@"herald-hybrid"];
    self.wkWebView = [[WKWebView alloc] initWithFrame:self.view.bounds configuration:configuration];
    self.wkWebView.backgroundColor = [UIColor yellowColor];
    NSURLRequest *req = [[NSURLRequest alloc] initWithURL:[NSURL URLWithString:@"https://app.52xiyou.com/m/1/104340682800/100687.html"]];
    [self.wkWebView loadRequest:req];
    [self.view addSubview:self.wkWebView];
    
    
    UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(0, 150, 100, 100)];
    btn.backgroundColor = [UIColor redColor];
    [btn addTarget:self action:@selector(btnClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
    
    
    UIButton *greenbtn = [[UIButton alloc] initWithFrame:CGRectMake(300, 150, 100, 100)];
    greenbtn.backgroundColor = [UIColor greenColor];
    [greenbtn addTarget:self action:@selector(greenbtnClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:greenbtn];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didReciveDataNoti:) name:@"DidReceiveDataNSNotificationName" object:nil];
}

- (void)didReciveDataNoti:(NSNotification *)notification{
    
    NSDictionary *notiDic = notification.userInfo;
    NSLog(@"拦截到的信息：%@",notiDic);
}

- (void)btnClick {
    [CustomURLProtocol stopMonitor];
}

- (void)greenbtnClick {
    [CustomURLProtocol startMonitor];
}

@end
