//
//  GRHWKURLSchemeHandler.h
//  HeraldApp
//
//  Created by Wolf-Tungsten on 2019/2/17.
//  Copyright © 2019 Herald Studio. All rights reserved.
//

#import <WebKit/WebKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface GRHWKURLSchemeHandler : NSObject<WKURLSchemeHandler>

@end

NS_ASSUME_NONNULL_END
